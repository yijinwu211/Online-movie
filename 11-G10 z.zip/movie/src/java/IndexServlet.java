import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.DBUtil;

/**
 * Servlet implementation class MoiveListServlet
 */
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IndexServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sql = "select * from t_movie where 1=1 ";
		String title = request.getParameter("title");
		request.setAttribute("title", title);
		if(title!=null&&title!="") {
			sql = sql + " and title like '%"+title+"%'";
		}
		String genre = request.getParameter("genre");
		request.setAttribute("genre", genre);
		if(genre!=null&&genre!="") {
			sql = sql + " and genre like '%"+genre+"%'";
		}
		sql = sql + " order by createtime desc";
		//get user access log
        List<Map<String, Object>> movies = DBUtil.query(sql,new Object[]{});
        request.setAttribute("movies", movies);
        
        //jump to home page
        request.getRequestDispatcher("/index.jsp").forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
