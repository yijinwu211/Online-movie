package movie;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.DBUtil;

/**
 * Servlet implementation class MoiveListServlet
 */
public class EditMovieDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditMovieDetailServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String title = request.getParameter("title");
		String genre = request.getParameter("genre");
		String price = request.getParameter("price");
		String numberofcopies = request.getParameter("numberofcopies");
		DBUtil.update("update t_movie set title=?,genre=?,price=?,numberofcopies=? where id=?", new Object[] {title,genre,price,numberofcopies,id});
		
		//get user access log
        List<Map<String, Object>> movies = DBUtil.query("select * from t_movie order by createtime desc",new Object[]{});
        request.setAttribute("movies", movies);
        
        //jump to home page
        request.getRequestDispatcher("/movie/list.jsp").forward(request,response);}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
