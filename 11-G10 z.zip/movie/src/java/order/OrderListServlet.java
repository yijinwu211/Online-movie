package order;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.DBUtil;

/**
 * Servlet implementation class OrderListServlet
 */
public class OrderListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sql = "select * from t_order where 1=1 and creator='"+request.getSession().getAttribute("email")+"'";
		String id = request.getParameter("number");
		request.setAttribute("number", id);
		if(id!=null&&id!="") {
			sql = sql + " and id="+id;
		}
		String starttime = request.getParameter("starttime");
		request.setAttribute("starttime", starttime);
		if(starttime!=null&&starttime!="") {
			sql = sql + " and createtime>='"+starttime+"'";
		}
		String endtime = request.getParameter("endtime");
		request.setAttribute("endtime", endtime);
		if(endtime!=null&&endtime!="") {
			sql = sql + " and createtime<='"+endtime+"'";
		}
		//get my order or analymous order
		List<Map<String, Object>> orders = DBUtil.query(sql,new Object[]{});
		request.setAttribute("orders", orders);
		
        //jump to home page
        request.getRequestDispatcher("/order/orderlist.jsp").forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
