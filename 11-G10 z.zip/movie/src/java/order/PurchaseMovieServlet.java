package order;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.DBUtil;

/**
 * Servlet implementation class PurchaseMovieServlet
 */
public class PurchaseMovieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PurchaseMovieServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            
            
            if(request.getSession().getAttribute("email")==null){
                String sql = "select * from t_movie where 1=1 ";
                List<Map<String, Object>> movies = DBUtil.query(sql,new Object[]{});
                request.setAttribute("movies", movies);
                //jump to home page
                request.getRequestDispatcher("/user/login.jsp").forward(request,response);
             }else{
		String id = request.getParameter("id");
		
		//set movie copy-1
		DBUtil.update("update t_movie set numberofcopies = numberofcopies-1 where id="+id+" and numberofcopies>0 ", new Object[] {});


        List<Map<String, Object>> movies = DBUtil.query("select * from t_movie where id="+id,new Object[]{});
        Map<String,Object> map = movies.get(0);
		//insert order
		String sql = "insert into t_order (movietitle,moviegenre,pricepercopy,creator,createtime,status)"
				+ "values(?,?,?,?,?,?)";
		DBUtil.insert(sql, new Object[] {map.get("title"),map.get("genre"),map.get("price"),request.getSession().getAttribute("email"),new Date(),0});
        
		//get my order or analymous order
		List<Map<String, Object>> orders = DBUtil.query("select * from t_order where creator='"+request.getSession().getAttribute("email")+"' order by createtime desc",new Object[]{});
		request.setAttribute("orders", orders);
		
        //jump to home page
        request.getRequestDispatcher("/order/orderlist.jsp").forward(request,response);
            }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
