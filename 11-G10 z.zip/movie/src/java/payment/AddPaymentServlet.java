/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payment;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import util.DBUtil;

/**
 *
 * @author kobe
 */
public class AddPaymentServlet extends HttpServlet{
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddPaymentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		String amount = request.getParameter("amount");
		DBUtil.insert("insert into t_payment(payment_method,payment_amount,payment_date)"
				+ "values(?,?,?)", new Object[] {method,amount,new Date()});

		//get user access log
        List<Map<String, Object>> payment = DBUtil.query("select * from t_payment order by payment_date desc",new Object[]{});
        request.setAttribute("payment", payment);

        //jump to home page
        request.getRequestDispatcher("/payment/PaymentList.jsp").forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
