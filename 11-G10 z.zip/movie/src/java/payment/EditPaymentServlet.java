package payment;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import util.DBUtil;

/**
 * Servlet implementation class EditPaymentServlet
 */
public class EditPaymentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditPaymentServlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        String sql = "select * from t_payment where id = " + id;
        List<Map<String, Object>> payment = DBUtil.query(sql, new Object[] {});
        HttpSession session = request.getSession();
        session.setAttribute("payment",payment);
        response.sendRedirect("/movie/payment/EditPayment.jsp");
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        String id = request.getParameter("id");
       // doGet(request, response);
        String method = request.getParameter("method");
        String amount = request.getParameter("amount");
        String date = request.getParameter("date");
        DBUtil.update(
                "update t_payment set payment_method = ?,payment_amount = ?,payment_date = ? where id = ?",
                new Object[] {method, amount, date, id});

        // get user access log
        List<Map<String, Object>> payment =
                DBUtil.query("select * from t_payment order by payment_date desc", new Object[] {});
        request.setAttribute("payment", payment);

        // jump to home page
        request.getRequestDispatcher("/payment/PaymentList.jsp").forward(request, response);
    }

}
