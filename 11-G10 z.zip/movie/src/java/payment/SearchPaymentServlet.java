package payment;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import util.DBUtil;

/**
 * Servlet implementation class SearchPaymentServlet
 */
public class SearchPaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchPaymentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sql = "select * from t_payment where 1=1 ";
		String id = request.getParameter("id");
		request.setAttribute("id", id);
		if(id!=null&&id!="") {
			sql += " and id = " + id;
		}
		String date = request.getParameter("date");
		request.setAttribute("date", date);
		date = "'"+ date +"%'";
		if(date!=null&&date!="") {
			sql += " and payment_date like " + date;
		}
		sql += " order by payment_date desc";
		//get user access log
        List<Map<String, Object>> payment = DBUtil.query(sql,new Object[]{});
        request.setAttribute("payment", payment);

        //jump to home page
        request.getRequestDispatcher("/payment/PaymentList.jsp").forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
