package user;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.DBUtil;

/**
 * Servlet implementation class UserLogAccessAction
 */
public class UserLogAccessAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLogAccessAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getSession().getAttribute("email")+"";
		String sql = "select * from t_log where 1=1 and email='"+email+"' ";
		String starttime = request.getParameter("starttime");
		if(starttime!=null&&starttime!="") {
			sql = sql + " and createtime>='"+starttime+"'";
			
		}
		String endtime = request.getParameter("endtime");
		if(endtime!=null&&endtime!="") {
			sql = sql + " and createtime<='"+endtime+"'";
			
		}
        //get user access log
        List<Map<String, Object>> logs = DBUtil.query(sql,new Object[]{});
        request.setAttribute("logs", logs);
        request.setAttribute("starttime", starttime);
        request.setAttribute("endtime", endtime);
        
        //jump to home page
        request.getRequestDispatcher("/user/home.jsp").forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
