package util;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
/**
 * static class used to conntect mysql
 */
public class DBUtil {

	private final static String URL = "jdbc:mysql://localhost:3306/movie?useUnicode=true&characterEncoding=UTF-8";
	private static final String USER = "root";
	private static final String PASSWORD = "root";

	static List<Map<String, Object>> ret = null;
	static PreparedStatement ps = null;
	static ResultSet rs = null;

	private static Connection conn = null;
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = (Connection) DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() {
		return conn;
	}


	public static List<Map<String, Object>> query(String sql, Object[] obj) {
		try {
			System.out.println("execute sql：" + sql);
			ps = conn.prepareStatement(sql);
			if (obj != null && obj.length > 0) {
				for (int i = 0, len = obj.length; i < len; i++) {
					ps.setObject(i + 1, obj[i]);
				}
			}
			if(ps.isClosed()) return null;
			rs = ps.executeQuery();
			ResultSetMetaData rmd = rs.getMetaData();
			ret = new ArrayList<Map<String, Object>>();
			while (rs.next()) {
				Map<String, Object> rowMap = new LinkedHashMap<String, Object>();
				for (int i = 1, count = rmd.getColumnCount() + 1; i < count; i++) {
					rowMap.put(rmd.getColumnName(i), rs.getObject(i));
				}
				ret.add(rowMap);
			}
		} catch (SQLException e) {
			System.out.println("execute failed,sql: " + sql + "," + e.getMessage());
			e.printStackTrace();
		}
		return ret;
	}

	public static int insert(String sql, Object[] obj) {
		int count = 0;
		try {
			System.out.println("execute sql：" + sql);
			ps = conn.prepareStatement(sql);
			if (obj != null && obj.length > 0) {
				for (int i = 0, len = obj.length; i < len; i++) {
					ps.setObject(i + 1, obj[i]);
				}
			}
			count = ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("execute failed,sql: " + sql + "," + e.getMessage());
			e.printStackTrace();
		} 
		return count;
	}

	public static int update(String sql, Object[] obj) {
		int count = 0;
		try {
			System.out.println("execute sql：" + sql);
			ps = conn.prepareStatement(sql);
			if (obj != null && obj.length > 0) {
				for (int i = 0, len = obj.length; i < len; i++) {
					ps.setObject(i + 1, obj[i]);
				}
			}
			count = ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("execute failed,sql: " + sql + "," + e.getMessage());
			e.printStackTrace();
		} 
		return count;
	}

	public static int delete(String sql, Object[] obj) {
		int count = 0;
		try {
			System.out.println("execute sql：" + sql);
			ps = conn.prepareStatement(sql);
			if (obj != null && obj.length > 0) {
				for (int i = 0, len = obj.length; i < len; i++) {
					ps.setObject(i + 1, obj[i]);
				}
			}
			count = ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("execute failed,sql: " + sql + "," + e.getMessage());
			e.printStackTrace();
		} 
		return count;
	}
}
