this project we use softwares below:
1.ide :netbeans
2.jdk:jdk1.8
3.webserver:tomcat8.5
4.database:mysql5.5
5.web resources:jsp,jquery,bootstrap
6:MVC mode:jsp servlet jdbcdao

operation indicate:
1.install jdk
2.install netbeans
3.install mysql
4.install tomcat
5.restore project from existing sources to netbeans
6.restore moive database
7.start tomcat from netbeans

when project was deployed,the index.jsp will show all moives,you can search moive by title or genre,also you 
can purchase a copy,of course you need to login to complete order,if you are in analymous mode,any operation
will jump to login page,when you login,you can do everything,after login,the login logs will be showen,you can
search you login logs based on time.
the moive catalogue mananement module will show all moives ,in this module ,you can create moive,edit moive,purchase copy of moive,
when purchase you will jump to order list,in this list,you can update your order,cancel you order,confirm your order,of course you
can search the list via different conditions

1. When installing netbeans, you can select the application server. Here, select your tomcat folder


2. When creating a new project, select tomcat server