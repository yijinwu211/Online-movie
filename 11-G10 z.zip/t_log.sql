/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : movie

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-05-31 17:53:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_log
-- ----------------------------
DROP TABLE IF EXISTS `t_log`;
CREATE TABLE `t_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createtime` datetime DEFAULT NULL,
  `logcontent` varchar(255) DEFAULT NULL,
  `logtype` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_log
-- ----------------------------
INSERT INTO `t_log` VALUES ('1', '2019-05-24 15:17:50', '1@1.com login success', 'login', null);
INSERT INTO `t_log` VALUES ('2', '2019-05-24 15:53:39', '1@1.com login success', 'login', null);
INSERT INTO `t_log` VALUES ('86', '2019-05-29 20:36:33', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('87', '2019-05-29 20:37:12', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('88', '2019-05-29 20:37:53', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('74', '2019-05-26 19:11:15', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('75', '2019-05-26 19:11:17', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('76', '2019-05-29 19:42:41', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('77', '2019-05-29 19:43:35', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('78', '2019-05-29 19:43:38', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('79', '2019-05-29 19:44:42', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('80', '2019-05-29 19:44:44', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('81', '2019-05-29 19:44:45', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('42', '2019-05-25 17:33:38', ' logout success', 'logout', '');
INSERT INTO `t_log` VALUES ('82', '2019-05-29 19:44:46', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('83', '2019-05-29 19:45:03', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('84', '2019-05-29 19:45:14', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('85', '2019-05-29 19:45:39', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('73', '2019-05-26 19:09:18', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('72', '2019-05-26 19:09:15', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('62', '2019-05-25 21:00:06', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('63', '2019-05-25 21:07:56', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('64', '2019-05-25 21:08:09', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('65', '2019-05-25 21:10:47', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('66', '2019-05-25 21:10:48', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('67', '2019-05-25 21:10:51', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('68', '2019-05-25 21:11:31', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('69', '2019-05-25 21:11:59', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('70', '2019-05-25 21:12:03', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('71', '2019-05-26 19:07:50', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('89', '2019-05-30 20:15:12', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('90', '2019-05-30 20:17:52', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('91', '2019-05-31 12:58:24', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('92', '2019-05-31 12:59:53', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('93', '2019-05-31 12:59:58', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('94', '2019-05-31 13:02:47', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('95', '2019-05-31 13:07:35', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('96', '2019-05-31 13:07:44', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('97', '2019-05-31 13:08:18', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('98', '2019-05-31 13:11:49', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('99', '2019-05-31 13:19:11', 'w@w.com login success', 'login', 'w@w.com');
INSERT INTO `t_log` VALUES ('100', '2019-05-31 13:35:34', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('101', '2019-05-31 13:40:40', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('102', '2019-05-31 13:42:54', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('103', '2019-05-31 13:58:46', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('104', '2019-05-31 15:38:14', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('105', '2019-05-31 15:48:38', '1@1.com logout success', 'logout', '1@1.com');
INSERT INTO `t_log` VALUES ('106', '2019-05-31 15:48:42', '1@1.com login success', 'login', '1@1.com');
INSERT INTO `t_log` VALUES ('107', '2019-05-31 15:49:43', '1@1.com login success', 'login', '1@1.com');

-- ----------------------------
-- Table structure for t_movie
-- ----------------------------
DROP TABLE IF EXISTS `t_movie`;
CREATE TABLE `t_movie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `numberofcopies` int(11) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_movie
-- ----------------------------
INSERT INTO `t_movie` VALUES ('2', 'b', 'g', '1', '0', '1@1.com', '2019-05-25 16:26:27');
INSERT INTO `t_movie` VALUES ('3', 'c', 'h', '1', '0', '1@1.com', '2019-05-25 16:28:16');
INSERT INTO `t_movie` VALUES ('4', 'd', 'i', '1', '0', '1@1.com', '2019-05-25 16:39:19');
INSERT INTO `t_movie` VALUES ('5', 'e', 'j', '1', '0', '1@1.com', '2019-05-25 16:39:22');
INSERT INTO `t_movie` VALUES ('10', 'testtitle222', 'testgenre', '101', '167', '1@1.com', '2019-05-25 21:04:17');

-- ----------------------------
-- Table structure for t_order
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `movietitle` varchar(255) DEFAULT NULL,
  `moviegenre` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `pricepercopy` decimal(10,0) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_order
-- ----------------------------
INSERT INTO `t_order` VALUES ('1', 'e', 'j', '1', '1', '1@1.com', '2019-05-25 20:12:26', '1');
INSERT INTO `t_order` VALUES ('2', 'd', 'i', '1', '1', '1@1.com', '2019-05-25 20:12:43', '-1');
INSERT INTO `t_order` VALUES ('3', 'c', 'h', '1', '1', '1@1.com', '2019-05-25 20:14:16', '1');
INSERT INTO `t_order` VALUES ('4', 'c', 'h', '1', '1', '1@1.com', '2019-05-25 20:14:43', '-1');
INSERT INTO `t_order` VALUES ('5', 'e', 'j', '1', '1', '1@1.com', '2019-05-25 20:22:03', '-1');
INSERT INTO `t_order` VALUES ('6', 'e', 'j', '1', '1', '1@1.com', '2019-05-25 20:22:22', '1');
INSERT INTO `t_order` VALUES ('7', 'e', 'j', '1', '1', '1@1.com', '2019-05-25 20:23:21', '0');
INSERT INTO `t_order` VALUES ('8', 'e', 'j', '1', '1', '1@1.com', '2019-05-25 20:23:51', '0');
INSERT INTO `t_order` VALUES ('9', 'e', 'j', '1', '1', '1@1.com', '2019-05-25 20:25:26', '0');
INSERT INTO `t_order` VALUES ('10', 'e', 'j', '1', '1', '1@1.com', '2019-05-25 20:27:16', '0');
INSERT INTO `t_order` VALUES ('11', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-25 21:08:28', '1');
INSERT INTO `t_order` VALUES ('12', 'testtitle222', 'testgenre', '1', '101', null, '2019-05-25 21:12:26', '0');
INSERT INTO `t_order` VALUES ('13', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-25 21:13:57', '0');
INSERT INTO `t_order` VALUES ('14', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-26 19:11:40', '0');
INSERT INTO `t_order` VALUES ('15', 'testtitle222', 'testgenre', '1', '101', null, '2019-05-29 19:37:38', '0');
INSERT INTO `t_order` VALUES ('16', 'testtitle222', 'testgenre', '1', '101', null, '2019-05-29 19:38:16', '0');
INSERT INTO `t_order` VALUES ('17', 'testtitle222', 'testgenre', '1', '101', null, '2019-05-29 19:38:31', '0');
INSERT INTO `t_order` VALUES ('18', 'testtitle222', 'testgenre', '1', '101', null, '2019-05-29 19:38:45', '0');
INSERT INTO `t_order` VALUES ('19', 'testtitle222', 'testgenre', '1', '101', null, '2019-05-29 19:39:12', '0');
INSERT INTO `t_order` VALUES ('20', 'testtitle222', 'testgenre', '1', '101', null, '2019-05-29 19:39:48', '0');
INSERT INTO `t_order` VALUES ('21', 'testtitle222', 'testgenre', '1', '101', null, '2019-05-29 19:39:50', '0');
INSERT INTO `t_order` VALUES ('22', 'testtitle222', 'testgenre', '1', '101', null, '2019-05-29 19:39:51', '0');
INSERT INTO `t_order` VALUES ('23', 'b', 'g', '1', '1', '1@1.com', '2019-05-29 19:43:20', '0');
INSERT INTO `t_order` VALUES ('24', 'b', 'g', '1', '1', '1@1.com', '2019-05-29 19:43:20', '0');
INSERT INTO `t_order` VALUES ('25', 'b', 'g', '1', '1', '1@1.com', '2019-05-29 19:43:20', '0');
INSERT INTO `t_order` VALUES ('26', 'b', 'g', '1', '1', '1@1.com', '2019-05-29 19:43:21', '0');
INSERT INTO `t_order` VALUES ('27', 'b', 'g', '1', '1', '1@1.com', '2019-05-29 19:43:21', '0');
INSERT INTO `t_order` VALUES ('28', 'b', 'g', '1', '1', '1@1.com', '2019-05-29 19:43:22', '0');
INSERT INTO `t_order` VALUES ('29', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:43:28', '0');
INSERT INTO `t_order` VALUES ('30', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:43:33', '0');
INSERT INTO `t_order` VALUES ('31', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:48:09', '0');
INSERT INTO `t_order` VALUES ('32', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:48:34', '0');
INSERT INTO `t_order` VALUES ('33', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:48:50', '0');
INSERT INTO `t_order` VALUES ('34', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:49:25', '0');
INSERT INTO `t_order` VALUES ('35', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:49:44', '0');
INSERT INTO `t_order` VALUES ('36', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:56:06', '0');
INSERT INTO `t_order` VALUES ('37', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:56:18', '0');
INSERT INTO `t_order` VALUES ('38', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:56:40', '0');
INSERT INTO `t_order` VALUES ('39', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:57:31', '0');
INSERT INTO `t_order` VALUES ('40', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:58:46', '0');
INSERT INTO `t_order` VALUES ('41', 'testtitle222', 'testgenre', '1', '101', '1@1.com', '2019-05-29 19:59:17', '0');
INSERT INTO `t_order` VALUES ('42', 'testtitle222', 'testgenre', '2', '101', '1@1.com', '2019-05-29 20:37:57', '0');
INSERT INTO `t_order` VALUES ('43', 'testtitle222', 'testgenre', '5', '101', '1@1.com', '2019-05-29 20:39:22', '1');
INSERT INTO `t_order` VALUES ('44', 'testtitle222', 'testgenre', '4', '101', '1@1.com', '2019-05-30 20:15:31', '-1');
INSERT INTO `t_order` VALUES ('45', 'testtitle222', 'testgenre', null, '101', '1@1.com', '2019-05-31 12:58:36', '1');
INSERT INTO `t_order` VALUES ('46', 'e', 'j', null, '1', '1@1.com', '2019-05-31 12:58:53', '0');
INSERT INTO `t_order` VALUES ('47', 'testtitle222', 'testgenre', '2', '101', '1@1.com', '2019-05-31 12:59:21', '1');
INSERT INTO `t_order` VALUES ('48', 'testtitle222', 'testgenre', null, '101', '1@1.com', '2019-05-31 13:02:44', '0');
INSERT INTO `t_order` VALUES ('49', 'd', 'i', null, '1', '1@1.com', '2019-05-31 13:09:26', '0');
INSERT INTO `t_order` VALUES ('50', 'd', 'i', '4', '1', '1@1.com', '2019-05-31 13:09:32', '1');
INSERT INTO `t_order` VALUES ('51', 'testtitle222', 'testgenre', null, '101', '1@1.com', '2019-05-31 13:10:14', '1');
INSERT INTO `t_order` VALUES ('52', 'testtitle222', 'testgenre', null, '101', '1@1.com', '2019-05-31 13:36:58', '0');
INSERT INTO `t_order` VALUES ('53', 'e', 'j', null, '1', '1@1.com', '2019-05-31 13:58:30', '1');
INSERT INTO `t_order` VALUES ('54', 'e', 'j', null, '1', '1@1.com', '2019-05-31 15:48:54', '1');
INSERT INTO `t_order` VALUES ('55', 'testtitle222', 'testgenre', null, '101', '1@1.com', '2019-05-31 15:50:17', '1');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', '1@1.com', '1', '123', null);
INSERT INTO `t_user` VALUES ('2', 'w@w.com', 'w', 'w', 'w');
